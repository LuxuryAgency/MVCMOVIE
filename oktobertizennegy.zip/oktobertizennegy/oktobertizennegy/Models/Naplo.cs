﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace oktobertizennegy.Models
{
    public class Naplo
    {
        [Key]
        public int Id { get; set; }
        [Required(ErrorMessage = "required")]
        public DateTime Datum { get; set; }

        [Required(ErrorMessage = "required")]
        public TimeSpan Ido {  get; set; }

        [Required(ErrorMessage = "required")]
        public int TelepulesId {  get; set; }
        [Column(TypeName ="float(10,1)")]
        public float? Magnitudo {  get; set; }

        [Column(TypeName = "float(10,1)")]
        public float? Intenzitas {  get; set; }

        public virtual Telepules? telepules { get; set; }

        
    }
}
