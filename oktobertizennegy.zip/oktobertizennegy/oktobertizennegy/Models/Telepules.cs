﻿using System.ComponentModel.DataAnnotations;

namespace oktobertizennegy.Models
{
    public class Telepules
    {
        [Key]
        public int Id {  get; set; }
        public string Nev {  get; set; }
        public string Varmegye {  get; set; }

        
    }
}
