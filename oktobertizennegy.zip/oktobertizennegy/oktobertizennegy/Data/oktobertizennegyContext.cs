﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using oktobertizennegy.Models;

namespace oktobertizennegy.Data
{
    public class oktobertizennegyContext : DbContext
    {
        public oktobertizennegyContext (DbContextOptions<oktobertizennegyContext> options)
            : base(options)
        {
        }

        public DbSet<oktobertizennegy.Models.Telepules> Telepules { get; set; } = default!;
        public DbSet<oktobertizennegy.Models.Naplo> Naplo { get; set; } = default!;
    }
}
