﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using oktobertizennegy.Data;
using oktobertizennegy.Models;

namespace oktobertizennegy.Controllers
{
    public class NaploesController : Controller
    {
        private readonly oktobertizennegyContext _context;

        public NaploesController(oktobertizennegyContext context)
        {
            _context = context;
        }

        // GET: Naploes
        public async Task<IActionResult> Index(string searchString,DateTime? minDate,DateTime? maxDate)
        {
            var result = await _context.Naplo.Include(t => t.telepules).ToListAsync();

            if (String.IsNullOrEmpty(searchString))
            {
                return View(result);
            }
            
            if (minDate != null)
            {
                result = (from r in result
                         where r.Datum>=minDate
                         select r).ToList();
                ViewData["CurrentMinDate"] = minDate.ToString();
            }
            if (maxDate != null)
            {
                result = result.Where(b => b.Datum >= minDate).ToList();
                ViewData["CurrentMinDate"] = minDate.ToString();
            }

            result = result.Where(t => t.telepules!.Nev.ToUpper().Contains(searchString.ToUpper())).ToList();
            ViewData["CurrentFilter"] = searchString;
            return View(result);
        }

        // GET: Naploes/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var naplo = await _context.Naplo
                .Include(n => n.telepules)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (naplo == null)
            {
                return NotFound();
            }

            return View(naplo);
        }

        // GET: Naploes/Create
        public IActionResult Create()
        {
            ViewData["TelepulesId"] = new SelectList(_context.Telepules, "Id", "Nev");
            return View();
        }

        // POST: Naploes/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,Datum,Ido,TelepulesId,Magnitudo,Intenzitas")] Naplo naplo)
        {
            if (ModelState.IsValid)
            {
                _context.Add(naplo);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["TelepulesId"] = new SelectList(_context.Telepules, "Id", "Id", naplo.TelepulesId);
            return View(naplo);
        }

        // GET: Naploes/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var naplo = await _context.Naplo.FindAsync(id);
            if (naplo == null)
            {
                return NotFound();
            }
            ViewData["TelepulesId"] = new SelectList(_context.Telepules, "Id", "Nev", naplo.TelepulesId);
            return View(naplo);
        }

        // POST: Naploes/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,Datum,Ido,TelepulesId,Magnitudo,Intenzitas")] Naplo naplo)
        {
            if (id != naplo.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(naplo);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!NaploExists(naplo.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["TelepulesId"] = new SelectList(_context.Telepules, "Id", "Id", naplo.TelepulesId);
            return View(naplo);
        }

        // GET: Naploes/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var naplo = await _context.Naplo
                .Include(n => n.telepules)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (naplo == null)
            {
                return NotFound();
            }

            return View(naplo);
        }

        // POST: Naploes/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var naplo = await _context.Naplo.FindAsync(id);
            if (naplo != null)
            {
                _context.Naplo.Remove(naplo);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool NaploExists(int id)
        {
            return _context.Naplo.Any(e => e.Id == id);
        }
    }
}
