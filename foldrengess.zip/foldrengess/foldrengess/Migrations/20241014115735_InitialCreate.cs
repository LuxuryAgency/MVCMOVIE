﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace foldrengess.Migrations
{
    /// <inheritdoc />
    public partial class InitialCreate : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Telepules",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Nev = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Varmegye = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Telepules", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Naplo",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Datum = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Ido = table.Column<TimeSpan>(type: "time", nullable: false),
                    TelepulesId = table.Column<int>(type: "int", nullable: false),
                    Magnitudo = table.Column<float>(type: "float(10)", nullable: true),
                    Intenzitas = table.Column<float>(type: "float(10)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Naplo", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Naplo_Telepules_TelepulesId",
                        column: x => x.TelepulesId,
                        principalTable: "Telepules",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Naplo_TelepulesId",
                table: "Naplo",
                column: "TelepulesId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Naplo");

            migrationBuilder.DropTable(
                name: "Telepules");
        }
    }
}
