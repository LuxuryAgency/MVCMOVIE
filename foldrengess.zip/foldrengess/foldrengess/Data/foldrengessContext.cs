﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using foldrengess.Models;

namespace foldrengess.Data
{
    public class foldrengessContext : DbContext
    {
        public foldrengessContext (DbContextOptions<foldrengessContext> options)
            : base(options)
        {
        }

        public DbSet<foldrengess.Models.Naplo> Naplo { get; set; } = default!;
        public DbSet<foldrengess.Models.Telepules> Telepules { get; set; } = default!;
    }
}
