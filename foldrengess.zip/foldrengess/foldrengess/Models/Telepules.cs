﻿using System.ComponentModel.DataAnnotations;

namespace foldrengess.Models
{
    public class Telepules
    {
        public int Id { get; set; }

        [Required]
        public string Nev { get; set; }

        [Required]
        public string Varmegye { get; set; }
    }
}
