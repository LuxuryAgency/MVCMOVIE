﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace foldrengess.Models
{
    public class Naplo
    {
        public int Id { get; set; }

        [Required]
        public DateTime Datum { get; set; }

        [Required]
        public TimeSpan Ido { get; set; }

        [Required]
        public int TelepulesId { get; set; }

        [Column(TypeName = "float(10,1)")]
        public float? Magnitudo { get; set; }
        [Column(TypeName ="float(10,1)")]
        public float? Intenzitas { get; set; }
        public virtual Telepules? Telepules { get; set; }


    }
}
