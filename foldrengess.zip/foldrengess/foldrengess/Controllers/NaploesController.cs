﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using foldrengess.Data;
using foldrengess.Models;

namespace foldrengess.Controllers
{
    public class NaploesController : Controller
    {
        private readonly foldrengessContext _context;

        public NaploesController(foldrengessContext context)
        {
            _context = context;
        }

        // GET: Naploes
        public async Task<IActionResult> Index(string searchString)
        {
            var result = await _context.Naplo.Include(t=>t.Telepules).ToListAsync();

            if (String.IsNullOrEmpty(searchString))
            {
                return View(result);
            }

            result = result.Where(t=>t.Telepules!.Nev.ToUpper().Contains(searchString.ToUpper())).ToList();
            ViewData["CurrentFilter"] = searchString;
            return View(result);

            
        }

        // GET: Naploes/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var naplo = await _context.Naplo
                .Include(n => n.Telepules)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (naplo == null)
            {
                return NotFound();
            }

            return View(naplo);
        }

        // GET: Naploes/Create
        public IActionResult Create()
        {
            ViewData["TelepulesId"] = new SelectList(_context.Telepules, "Id", "Nev");
            return View();
        }

        // POST: Naploes/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,Datum,Ido,TelepulesId,Magnitudo,Intenzitas")] Naplo naplo)
        {
            if (ModelState.IsValid)
            {
                _context.Add(naplo);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["TelepulesId"] = new SelectList(_context.Telepules, "Id", "Nev", naplo.TelepulesId);
            return View(naplo);
        }

        // GET: Naploes/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var naplo = await _context.Naplo.FindAsync(id);
            if (naplo == null)
            {
                return NotFound();
            }
            ViewData["TelepulesId"] = new SelectList(_context.Telepules, "Id", "Nev", naplo.TelepulesId);
            return View(naplo);
        }

        // POST: Naploes/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,Datum,Ido,TelepulesId,Magnitudo,Intenzitas")] Naplo naplo)
        {
            if (id != naplo.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(naplo);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!NaploExists(naplo.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["TelepulesId"] = new SelectList(_context.Telepules, "Id", "Nev", naplo.TelepulesId);
            return View(naplo);
        }

        // GET: Naploes/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var naplo = await _context.Naplo
                .Include(n => n.Telepules)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (naplo == null)
            {
                return NotFound();
            }

            return View(naplo);
        }

        // POST: Naploes/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var naplo = await _context.Naplo.FindAsync(id);
            if (naplo != null)
            {
                _context.Naplo.Remove(naplo);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool NaploExists(int id)
        {
            return _context.Naplo.Any(e => e.Id == id);
        }
    }
}
